var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/helloworld', function(req, res) {
	res.render('helloworld', { title: 'Hello World!' });
});

router.get('/userlist', function(req, res) {
	var db = req.db
	var collection = db.get('usercollection');
	collection.find({}, {}, function(e, docs) {
		res.render('userlist', {
			"userlist": docs
		});
	});
});

router.get('/newuser', function(req, res) {
	res.render('newuser', { title: 'Add New User' });
});

router.post('/adduser', function(req, res) {
	var db = req.db;

	var fname = req.body.fname;
	var lname = req.body.lname;
	var email = req.body.email;

	var collection = db.get('usercollection');

	collection.insert({
		"fname": fname,
		"lname": lname,
		"email": email,
		"locationData": []
	}, function (err, doc) {
		if (err) {
			res.send("There was a problem adding to the database");
		} else {
			res.send("Added " + fname + " " + lname + " " + email + " to the database");
		}
	});
});

router.post('/updateLocation', function(req, res) {
	var db = req.db;

	var fname = req.body.fname;
	var lname = req.body.lname;
	var email = req.body.email;

	var newLocation = {}
	newLocation["altitude"] = req.body.altitude
	newLocation["timestamp"] = req.body.timestamp
	newLocation["speed"] = req.body.speed
	newLocation["latitude"] = req.body.latitude
	newLocation["longitude"] = req.body.longitude
	newLocation["floor"] = req.body.floor
	newLocation["horizontalAccuracy"] = req.body.horizontalAccuracy	
	newLocation["verticalAccuracy"] = req.body.verticalAccuracy

	var collection = db.get('usercollection');
	var person = collection.find({"fname": fname, "lname": lname, "email": email});
	console.log("Who is the person ? " + person);

	collection.update(
		{"fname": fname, "lname": lname, "email": email},
		{
			$addToSet: {locationData: newLocation}
		}, function (err, doc) {
			if (err) {
				res.send("There was a problem updating the user's location");
			} else {
				res.send("Added location data for " + fname + " " + lname);
			}
	});
});



module.exports = router;
